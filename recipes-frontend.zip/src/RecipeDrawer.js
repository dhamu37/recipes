import React, {useState} from 'react';

export default function RecipeDrawer({item, onClose}){
  const [expanded, setExpanded] = useState(false);
  const nutrients = (()=>{
    try{ return item.nutrientsJson ? JSON.parse(item.nutrientsJson) : {}; }catch(e){ return {}; }
  })();
  return (
    <div className="drawer">
      <div><strong>{item.title}</strong> <span style={{color:'#666'}}>({item.cuisine})</span> <button className="close" onClick={onClose}>Close</button></div>
      <div style={{marginTop:12}}><strong>Description</strong>
        <div>{item.description}</div>
      </div>
      <div style={{marginTop:12}}>
        <strong>Total Time</strong> {item.totalTime} mins
        <button style={{marginLeft:8}} onClick={()=>setExpanded(s=>!s)}>{expanded? 'Hide' : 'Show Prep/Cook'}</button>
        {expanded && <div style={{marginTop:8}}>Prep: {item.prepTime} mins | Cook: {item.cookTime} mins</div>}
      </div>

      <div style={{marginTop:12}}>
        <strong>Nutrition</strong>
        <table style={{width:'100%',marginTop:8,borderCollapse:'collapse'}}>
          <thead><tr><th style={{textAlign:'left'}}>Nutrient</th><th style={{textAlign:'left'}}>Value</th></tr></thead>
          <tbody>
            {['calories','carbohydrateContent','cholesterolContent','fiberContent','proteinContent','saturatedFatContent','sodiumContent','sugarContent','fatContent'].map(k=>(
              <tr key={k}><td style={{padding:'6px 4px'}}>{k}</td><td style={{padding:'6px 4px'}}>{nutrients[k] ?? '-'}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
