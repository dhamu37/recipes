export async function searchRecipes(params){
  const qs = new URLSearchParams();
  if(params.title) qs.set('title', params.title);
  if(params.cuisine) qs.set('cuisine', params.cuisine);
  if(params.minRating) qs.set('minRating', params.minRating);
  qs.set('page', params.page ?? 0);
  qs.set('size', params.size ?? 15);
  // sorting default left out
  const res = await fetch('/api/recipes/search?' + qs.toString());
  if(!res.ok) throw new Error('Request failed ' + res.status);
  return res.json();
}
