import React, {useState, useEffect} from 'react';
import RecipeTable from './RecipeTable';
import RecipeDrawer from './RecipeDrawer';
import {searchRecipes} from './api/recipeApi';

export default function App(){
  const [filters, setFilters] = useState({title:'', cuisine:'', minRating:''});
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(15);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(null);

  const load = async (p=page, s=size, f=filters) => {
    setLoading(true);
    try{
      const resp = await searchRecipes({...f, page:p, size:s});
      setData(resp);
    }catch(e){
      console.error(e);
      setData(null);
    }finally{ setLoading(false); }
  };

  useEffect(()=>{ load(0, size, filters); setPage(0); }, [size]);

  const applyFilters = ()=>{ load(0,size,filters); setPage(0); };

  return (
    <div className="app">
      <div className="header"><h2>Recipes Browser</h2><div>Results: {data?data.totalElements: '-'}</div></div>
      <div className="controls">
        <input placeholder="Title" value={filters.title} onChange={e=>setFilters({...filters,title:e.target.value})} />
        <input placeholder="Cuisine" value={filters.cuisine} onChange={e=>setFilters({...filters,cuisine:e.target.value})} />
        <input placeholder="Min Rating" type="number" step="0.1" value={filters.minRating} onChange={e=>setFilters({...filters,minRating:e.target.value})} />
        <select value={size} onChange={e=>setSize(Number(e.target.value))}>
          <option value={15}>15</option><option value={25}>25</option><option value={50}>50</option>
        </select>
        <button onClick={applyFilters}>Apply</button>
      </div>

      {loading && <div>Loading...</div>}
      {!loading && data && data.content && data.content.length===0 && <div className="no-data">No results found.</div>}

      {!loading && data && data.content && data.content.length>0 && (
        <RecipeTable rows={data.content} onRowClick={r=>setSelected(r)} />
      )}

      {data && (
        <div className="pagination">
          <button onClick={()=>{ if(page>0){ setPage(p=>p-1); load(page-1,size,filters);} }} disabled={page<=0}>Prev</button>
          <div>Page {page+1} / {Math.max(1, Math.ceil((data.totalElements||0)/size))}</div>
          <button onClick={()=>{ const max = Math.max(0, Math.ceil((data.totalElements||0)/size)-1); if(page<max){ setPage(p=>p+1); load(page+1,size,filters);} }} disabled={ (page+1)*size >= (data.totalElements||0) }>Next</button>
        </div>
      )}

      {selected && <RecipeDrawer item={selected} onClose={()=>setSelected(null)} />}
    </div>
  );
}
