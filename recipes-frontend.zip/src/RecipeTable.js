import React from 'react';

function Stars({value}){
  const full = Math.floor(value||0);
  const half = (value - full) >= 0.5;
  const stars = [];
  for(let i=0;i<5;i++){
    if(i<full) stars.push('★');
    else if(i===full && half) stars.push('☆');
    else stars.push('☆');
  }
  return <span className="rating" title={(value||0).toString()}>{stars.join('')}</span>;
}

export default function RecipeTable({rows,onRowClick}){
  return (
    <table className="table">
      <thead>
        <tr><th>Title</th><th>Cuisine</th><th>Rating</th><th>Total Time</th><th>Serves</th></tr>
      </thead>
      <tbody>
        {rows.map(r=>(
          <tr key={r.id} className="row" onClick={()=>onRowClick(r)}>
            <td className="truncate">{r.title}</td>
            <td>{r.cuisine}</td>
            <td><Stars value={r.rating} /></td>
            <td>{r.totalTime ?? ( (r.prepTime||0) + (r.cookTime||0) )} mins</td>
            <td>{r.serves}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
