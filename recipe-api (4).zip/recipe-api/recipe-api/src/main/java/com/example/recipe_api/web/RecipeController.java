package com.example.recipe_api.web;

import com.example.recipe_api.dto.RecipeResponseDTO;
import com.example.recipe_api.mapper.RecipeMapper;
import com.example.recipe_api.model.Recipe;
import com.example.recipe_api.service.RecipeService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/recipes")
public class RecipeController {

    private final RecipeService svc;

    public RecipeController(RecipeService svc) {
        this.svc = svc;
    }

    private Sort parseSort(String sortParam) {
        if (sortParam == null || sortParam.isBlank()) return Sort.by("id").ascending();
        String[] parts = sortParam.split(",");
        String prop = parts[0];
        boolean desc = parts.length > 1 && parts[1].equalsIgnoreCase("desc");
        return desc ? Sort.by(prop).descending() : Sort.by(prop).ascending();
    }


    @GetMapping
    public Page<RecipeResponseDTO> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id,asc") String sort) {

        Sort sorting = parseSort(sort);
        Page<Recipe> recipes = svc.findAll(page, size, sorting);


        return recipes.map(r -> {
            RecipeResponseDTO dto = new RecipeResponseDTO();
            dto.setId(r.getId());
            dto.setCuisine(r.getCuisine());
            dto.setTitle(r.getTitle());
            dto.setRating(r.getRating());
            dto.setPrepTime(r.getPrepTime());
            dto.setCookTime(r.getCookTime());
            dto.setTotalTime(r.getTotalTime());
            dto.setDescription(r.getDescription());
            dto.setNutrientsJson(r.getNutrientsJson());
            dto.setServes(r.getServes());
            return dto;
        });
    }


    @GetMapping("/search")
    public Page<RecipeResponseDTO> search(
            @RequestParam Optional<String> cuisine,
            @RequestParam Optional<String> title,
            @RequestParam Optional<Double> minRating,
            @RequestParam Optional<Double> maxRating,
            @RequestParam Optional<Integer> minPrep,
            @RequestParam Optional<Integer> maxPrep,
            @RequestParam Optional<Integer> minCook,
            @RequestParam Optional<Integer> maxCook,
            @RequestParam Optional<Integer> minTotal,
            @RequestParam Optional<Integer> maxTotal,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id,asc") String sort) {

        Sort sorting = parseSort(sort);
        Page<Recipe> recipes = svc.search(cuisine, title, minRating, maxRating, minPrep, maxPrep, minCook, maxCook, minTotal, maxTotal, page, size, sorting);

        return recipes.map(r -> {
            RecipeResponseDTO dto = new RecipeResponseDTO();
            dto.setId(r.getId());
            dto.setCuisine(r.getCuisine());
            dto.setTitle(r.getTitle());
            dto.setRating(r.getRating());
            dto.setPrepTime(r.getPrepTime());
            dto.setCookTime(r.getCookTime());
            dto.setTotalTime(r.getTotalTime());
            dto.setDescription(r.getDescription());
            dto.setNutrientsJson(r.getNutrientsJson());
            dto.setServes(r.getServes());
            return dto;
        });
    }
}
