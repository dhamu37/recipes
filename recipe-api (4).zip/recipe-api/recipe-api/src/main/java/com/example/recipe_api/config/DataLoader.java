
package com.example.recipe_api.config;

import com.example.recipe_api.model.Recipe;
import com.example.recipe_api.service.RecipeService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.config.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;



@Component
public class DataLoader implements CommandLineRunner {

    private final RecipeService svc;
    private final ObjectMapper mapper = new ObjectMapper();

    public DataLoader(RecipeService svc) {
        this.svc = svc;
    }


    @Override
    public void run(String... args) throws Exception {


        ClassPathResource resource = new ClassPathResource("recipes.json");

        if (!resource.exists()) {
            System.out.println("recipes.json not found — skipping data load.");
            return;
        }

        try (InputStream is = resource.getInputStream()) {
            JsonNode root = mapper.readTree(is);

            if (root.isArray()) {
                int count = 0;
                for (JsonNode n : root) {
                    Recipe r = parseNode(n);
                    svc.save(r);
                    count++;
                }
                System.out.println("Loaded " + count + " recipes from recipes.json");
                return;
            }

            if (root.isObject()) {
                int imported = 0;
                Iterator<Map.Entry<String, JsonNode>> fields = root.fields();
                while (fields.hasNext()) {
                    JsonNode node = fields.next().getValue();
                    if (node != null && node.isObject()) {
                        Recipe r = parseNode(node);
                        svc.save(r);
                        imported++;
                    }
                }
                System.out.println("Loaded " + imported + " recipes from recipes.json");
                return;
            }

            System.out.println("Unsupported JSON format in recipes.json — must be array or object-of-objects.");
        }

    }

    private Recipe parseNode(JsonNode n) {
        Recipe r = new Recipe();
        r.setCuisine(textOrNull(n, "cuisine"));
        r.setTitle(textOrNull(n, "title"));
        r.setRating(doubleOrNull(n, "rating"));
        r.setPrepTime(intOrNull(n, "prep_time"));
        r.setCookTime(intOrNull(n, "cook_time"));
        r.setTotalTime(intOrNull(n, "total_time"));
        r.setDescription(textOrNull(n, "description"));

        if (n.has("nutrients")) {
            try { r.setNutrientsJson(mapper.writeValueAsString(n.get("nutrients"))); }
            catch (Exception ex) { r.setNutrientsJson(null); }
        }

        r.setServes(textOrNull(n, "serves"));

        return r;
    }


    private String textOrNull(JsonNode n, String field) {
        if (!n.has(field) || n.get(field).isNull()) return null;
        String v = n.get(field).asText();
        if (v == null || v.isBlank() || v.equalsIgnoreCase("NaN")) return null;
        return v;
    }

    private Double doubleOrNull(JsonNode n, String field) {
        if (!n.has(field) || n.get(field).isNull()) return null;
        JsonNode v = n.get(field);
        if (v.isNumber()) return v.doubleValue();
        try {
            String s = v.asText();
            if (s == null || s.isBlank() || s.equalsIgnoreCase("NaN")) return null;
            return Double.parseDouble(s);
        } catch (Exception e) { return null; }
    }

    private Integer intOrNull(JsonNode n, String field) {
        if (!n.has(field) || n.get(field).isNull()) return null;
        JsonNode v = n.get(field);
        if (v.isInt() || v.isLong()) return v.intValue();
        try {
            String s = v.asText();
            if (s == null || s.isBlank() || s.equalsIgnoreCase("NaN")) return null;
            Double d = Double.parseDouble(s);
            return d.intValue();
        } catch (Exception e) { return null; }
    }
}
