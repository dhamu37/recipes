package com.example.recipe_api.mapper;

import com.example.recipe_api.dto.RecipeResponseDTO;
import com.example.recipe_api.model.Recipe;

public class RecipeMapper {

    public static RecipeResponseDTO toDto(Recipe r) {
        if (r == null) return null;
        RecipeResponseDTO dto = new RecipeResponseDTO();
        dto.setId(r.getId());
        dto.setCuisine(r.getCuisine());
        dto.setTitle(r.getTitle());
        dto.setRating(r.getRating());
        dto.setPrepTime(r.getPrepTime());
        dto.setCookTime(r.getCookTime());
        dto.setTotalTime(r.getTotalTime());
        dto.setDescription(r.getDescription());
        dto.setNutrientsJson(r.getNutrientsJson());
        dto.setServes(r.getServes());
        return dto;
    }
}
