package com.example.recipe_api.dto;

public class RecipeSearchRequest {
    private String cuisine;
    private String title;
    private Double minRating;
    private Double maxRating;
    private Integer minPrep;
    private Integer maxPrep;
    private Integer minCook;
    private Integer maxCook;
    private Integer minTotal;
    private Integer maxTotal;

}
