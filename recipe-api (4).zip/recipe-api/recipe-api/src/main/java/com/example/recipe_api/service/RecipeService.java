package com.example.recipe_api.service;

import com.example.recipe_api.model.Recipe;
import com.example.recipe_api.repository.RecipeRepository;
import com.example.recipe_api.spec.RecipeSpecifications;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RecipeService {

    private final RecipeRepository repo;

    public RecipeService(RecipeRepository repo) {
        this.repo = repo;
    }


    public Page<Recipe> findAll(int page, int size, Sort sort) {
        Pageable pageable = PageRequest.of(page, size, sort);
        return repo.findAll(pageable);
    }


    public Page<Recipe> search(Optional<String> cuisine,
                               Optional<String> title,
                               Optional<Double> minRating,
                               Optional<Double> maxRating,
                               Optional<Integer> minPrep,
                               Optional<Integer> maxPrep,
                               Optional<Integer> minCook,
                               Optional<Integer> maxCook,
                               Optional<Integer> minTotal,
                               Optional<Integer> maxTotal,
                               int page, int size, Sort sort) {

        Specification<Recipe> spec = Specification.where(null);

        if (cuisine.isPresent()) spec = spec.and(RecipeSpecifications.cuisineEquals(cuisine.get()));
        if (title.isPresent()) spec = spec.and(RecipeSpecifications.titleContains(title.get()));
        if (minRating.isPresent() || maxRating.isPresent())
            spec = spec.and(RecipeSpecifications.ratingBetween(minRating.orElse(null), maxRating.orElse(null)));
        if (minPrep.isPresent() || maxPrep.isPresent())
            spec = spec.and(RecipeSpecifications.prepTimeBetween(minPrep.orElse(null), maxPrep.orElse(null)));
        if (minCook.isPresent() || maxCook.isPresent())
            spec = spec.and(RecipeSpecifications.cookTimeBetween(minCook.orElse(null), maxCook.orElse(null)));
        if (minTotal.isPresent() || maxTotal.isPresent())
            spec = spec.and(RecipeSpecifications.totalTimeBetween(minTotal.orElse(null), maxTotal.orElse(null)));

        Pageable pageable = PageRequest.of(page, size, sort);
        return repo.findAll(spec, pageable);
    }

    public Recipe save(Recipe recipe) {
        return repo.save(recipe);
    }
}
