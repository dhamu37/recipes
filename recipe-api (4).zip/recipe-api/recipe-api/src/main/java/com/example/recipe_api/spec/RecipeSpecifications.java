package com.example.recipe_api.spec;

import com.example.recipe_api.model.Recipe;
import org.springframework.data.jpa.domain.Specification;

public final class RecipeSpecifications {

    private RecipeSpecifications() {}

    public static Specification<Recipe> cuisineEquals(String cuisine) {
        return (root, query, cb) ->
                (cuisine == null || cuisine.isBlank()) ? null :
                        cb.equal(cb.lower(root.get("cuisine")), cuisine.toLowerCase());
    }

    public static Specification<Recipe> titleContains(String title) {
        return (root, query, cb) ->
                (title == null || title.isBlank()) ? null :
                        cb.like(cb.lower(root.get("title")), "%" + title.toLowerCase() + "%");
    }

    public static Specification<Recipe> ratingBetween(Double min, Double max) {
        return (root, query, cb) -> {
            if (min == null && max == null) return null;
            if (min == null) return cb.le(root.get("rating"), max);
            if (max == null) return cb.ge(root.get("rating"), min);
            return cb.between(root.get("rating"), min, max);
        };
    }

    public static Specification<Recipe> prepTimeBetween(Integer min, Integer max) {
        return (root, query, cb) -> {
            if (min == null && max == null) return null;
            if (min == null) return cb.le(root.get("prepTime"), max);
            if (max == null) return cb.ge(root.get("prepTime"), min);
            return cb.between(root.get("prepTime"), min, max);
        };
    }

    // cookTimeBetween and totalTimeBetween same pattern
    public static Specification<Recipe> cookTimeBetween(Integer min, Integer max) {
        return (root, query, cb) -> {
            if (min == null && max == null) return null;
            if (min == null) return cb.le(root.get("cookTime"), max);
            if (max == null) return cb.ge(root.get("cookTime"), min);
            return cb.between(root.get("cookTime"), min, max);
        };
    }

    public static Specification<Recipe> totalTimeBetween(Integer min, Integer max) {
        return (root, query, cb) -> {
            if (min == null && max == null) return null;
            if (min == null) return cb.le(root.get("totalTime"), max);
            if (max == null) return cb.ge(root.get("totalTime"), min);
            return cb.between(root.get("totalTime"), min, max);
        };
    }
}
