package com.example.recipe_api.repository;

import com.example.recipe_api.model.Recipe;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class RecipeRepositoryTest {

    @Autowired
    private com.example.recipe_api.repository.RecipeRepository repo;

    @Test
    public void testSaveAndFind() {
        Recipe r = new Recipe();
        r.setTitle("Test Pie");
        r.setCuisine("Test Cuisine");
        r.setRating(4.5);
        r = repo.save(r);

        assertThat(r.getId()).isNotNull();

        Recipe found = repo.findById(r.getId()).orElse(null);
        assertThat(found).isNotNull();
        assertThat(found.getTitle()).isEqualTo("Test Pie");
    }
}
